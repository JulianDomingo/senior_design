This is freeware software; use it however you wish.
Jon Valvano
