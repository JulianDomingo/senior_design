These examples accompany the book
   
"Embedded Systems: Introduction to the MSP432 Microcontroller",
   
ISBN: 978-1512185676, Jonathan Valvano, copyright (c) 2015
   

Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    

You may use, edit, run or distribute these file
s  as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/

June 22, 2015
